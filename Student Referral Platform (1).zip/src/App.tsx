import { useState, useEffect } from 'react';
import { LandingPage } from './components/LandingPage';
import { StudentDashboard } from './components/StudentDashboard';
import { EmployeeDashboard } from './components/EmployeeDashboard';
import { StudentOnboarding } from './components/StudentOnboarding';
import { EmployeeOnboarding } from './components/EmployeeOnboarding';
import { apiClient } from './utils/api';

type UserType = 'student' | 'employee' | null;
type Page = 'landing' | 'student-onboarding' | 'employee-onboarding' | 'student-dashboard' | 'employee-dashboard';

interface User {
  id: string;
  type: UserType;
  name: string;
  email: string;
  profile?: any;
}

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('landing');
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Check for existing session on app load
  useEffect(() => {
    const checkSession = async () => {
      const storedUser = localStorage.getItem('referral_user');
      const storedToken = localStorage.getItem('referral_token');
      
      if (storedUser && storedToken) {
        try {
          const user = JSON.parse(storedUser);
          apiClient.setAccessToken(storedToken);
          
          // Verify the session is still valid
          const { error } = await apiClient.getProfile();
          if (!error) {
            setCurrentUser(user);
            if (user.type === 'student') {
              setCurrentPage('student-dashboard');
            } else {
              setCurrentPage('employee-dashboard');
            }
          } else {
            // Session invalid, clear storage
            localStorage.removeItem('referral_user');
            localStorage.removeItem('referral_token');
          }
        } catch (error) {
          console.error('Session check error:', error);
          localStorage.removeItem('referral_user');
          localStorage.removeItem('referral_token');
        }
      }
      setIsLoading(false);
    };
    
    checkSession();
  }, []);

  const navigateTo = (page: Page) => {
    setCurrentPage(page);
  };

  const handleUserLogin = (user: User, accessToken?: string) => {
    setCurrentUser(user);
    
    // Store user session
    localStorage.setItem('referral_user', JSON.stringify(user));
    if (accessToken) {
      localStorage.setItem('referral_token', accessToken);
      apiClient.setAccessToken(accessToken);
    }
    
    if (user.type === 'student') {
      navigateTo('student-dashboard');
    } else {
      navigateTo('employee-dashboard');
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    apiClient.setAccessToken(null);
    localStorage.removeItem('referral_user');
    localStorage.removeItem('referral_token');
    navigateTo('landing');
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center mx-auto mb-4 animate-pulse">
            <div className="w-4 h-4 bg-primary-foreground rounded"></div>
          </div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {currentPage === 'landing' && (
        <LandingPage onNavigate={navigateTo} onLogin={handleUserLogin} />
      )}
      
      {currentPage === 'student-onboarding' && (
        <StudentOnboarding 
          onComplete={handleUserLogin}
          onBack={() => navigateTo('landing')}
        />
      )}
      
      {currentPage === 'employee-onboarding' && (
        <EmployeeOnboarding 
          onComplete={handleUserLogin}
          onBack={() => navigateTo('landing')}
        />
      )}
      
      {currentPage === 'student-dashboard' && currentUser && (
        <StudentDashboard 
          user={currentUser}
          onLogout={handleLogout}
        />
      )}
      
      {currentPage === 'employee-dashboard' && currentUser && (
        <EmployeeDashboard 
          user={currentUser}
          onLogout={handleLogout}
        />
      )}
    </div>
  );
}