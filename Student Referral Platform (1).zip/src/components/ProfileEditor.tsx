import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Edit, Loader2, Save, X } from 'lucide-react';
import { apiClient } from '../utils/api';

interface StudentProfile {
  university: string;
  degree: string;
  graduationYear: string;
  skills: string;
  bio: string;
}

interface EmployeeProfile {
  company: string;
  position: string;
  department: string;
  experience: string;
  bio?: string;
}

interface ProfileEditorProps {
  user: {
    id: string;
    type: 'student' | 'employee';
    name: string;
    email: string;
    profile: StudentProfile | EmployeeProfile;
  };
  onProfileUpdate: (updatedUser: any) => void;
}

export function ProfileEditor({ user, onProfileUpdate }: ProfileEditorProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  
  const [editData, setEditData] = useState({
    name: user.name,
    profile: { ...user.profile }
  });

  const handleSave = async () => {
    setIsLoading(true);
    
    try {
      const { data, error } = await apiClient.updateProfile(editData);
      
      if (error) {
        console.error('Failed to update profile:', error);
        alert('Failed to update profile. Please try again.');
      } else {
        // Update the user object with new data
        const updatedUser = {
          ...user,
          name: editData.name,
          profile: { ...editData.profile }
        };
        
        onProfileUpdate(updatedUser);
        setIsEditing(false);
        
        // Show success message
        alert('Profile updated successfully!');
      }
    } catch (error) {
      console.error('Error updating profile:', error);
      alert('An unexpected error occurred. Please try again.');
    }
    
    setIsLoading(false);
  };

  const handleCancel = () => {
    setEditData({
      name: user.name,
      profile: { ...user.profile }
    });
    setIsEditing(false);
  };

  const renderStudentFields = () => {
    const profile = editData.profile as StudentProfile;
    
    return (
      <>
        <div>
          <Label htmlFor="university">University</Label>
          <Input
            id="university"
            value={profile.university || ''}
            onChange={(e) => setEditData(prev => ({
              ...prev,
              profile: { ...prev.profile, university: e.target.value }
            }))}
            placeholder="e.g., Stanford University"
          />
        </div>
        
        <div>
          <Label htmlFor="degree">Degree</Label>
          <Input
            id="degree"
            value={profile.degree || ''}
            onChange={(e) => setEditData(prev => ({
              ...prev,
              profile: { ...prev.profile, degree: e.target.value }
            }))}
            placeholder="e.g., Computer Science"
          />
        </div>
        
        <div>
          <Label htmlFor="graduationYear">Expected Graduation</Label>
          <Input
            id="graduationYear"
            value={profile.graduationYear || ''}
            onChange={(e) => setEditData(prev => ({
              ...prev,
              profile: { ...prev.profile, graduationYear: e.target.value }
            }))}
            placeholder="e.g., 2025"
          />
        </div>
        
        <div>
          <Label htmlFor="skills">Skills</Label>
          <Input
            id="skills"
            value={profile.skills || ''}
            onChange={(e) => setEditData(prev => ({
              ...prev,
              profile: { ...prev.profile, skills: e.target.value }
            }))}
            placeholder="e.g., React, Python, JavaScript"
          />
        </div>
        
        <div>
          <Label htmlFor="bio">Bio</Label>
          <Textarea
            id="bio"
            value={profile.bio || ''}
            onChange={(e) => setEditData(prev => ({
              ...prev,
              profile: { ...prev.profile, bio: e.target.value }
            }))}
            placeholder="Tell us about yourself, your interests, and what you're looking for..."
            className="min-h-[100px]"
          />
        </div>
      </>
    );
  };

  const renderEmployeeFields = () => {
    const profile = editData.profile as EmployeeProfile;
    
    return (
      <>
        <div>
          <Label htmlFor="company">Company</Label>
          <Input
            id="company"
            value={profile.company || ''}
            onChange={(e) => setEditData(prev => ({
              ...prev,
              profile: { ...prev.profile, company: e.target.value }
            }))}
            placeholder="e.g., Google, Microsoft"
          />
        </div>
        
        <div>
          <Label htmlFor="position">Position</Label>
          <Input
            id="position"
            value={profile.position || ''}
            onChange={(e) => setEditData(prev => ({
              ...prev,
              profile: { ...prev.profile, position: e.target.value }
            }))}
            placeholder="e.g., Senior Software Engineer"
          />
        </div>
        
        <div>
          <Label htmlFor="department">Department</Label>
          <Input
            id="department"
            value={profile.department || ''}
            onChange={(e) => setEditData(prev => ({
              ...prev,
              profile: { ...prev.profile, department: e.target.value }
            }))}
            placeholder="e.g., Engineering, Product"
          />
        </div>
        
        <div>
          <Label htmlFor="experience">Experience</Label>
          <Input
            id="experience"
            value={profile.experience || ''}
            onChange={(e) => setEditData(prev => ({
              ...prev,
              profile: { ...prev.profile, experience: e.target.value }
            }))}
            placeholder="e.g., 5 years"
          />
        </div>
        
        <div>
          <Label htmlFor="bio">Professional Bio</Label>
          <Textarea
            id="bio"
            value={profile.bio || ''}
            onChange={(e) => setEditData(prev => ({
              ...prev,
              profile: { ...prev.profile, bio: e.target.value }
            }))}
            placeholder="Tell us about your professional background and what you look for in candidates..."
            className="min-h-[100px]"
          />
        </div>
      </>
    );
  };

  const renderDisplayFields = () => {
    if (user.type === 'student') {
      const profile = user.profile as StudentProfile;
      return (
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <Label>Name</Label>
            <p className="text-sm font-medium">{user.name}</p>
          </div>
          
          <div>
            <Label>Email</Label>
            <p className="text-sm font-medium">{user.email}</p>
          </div>
          
          <div>
            <Label>University</Label>
            <p className="text-sm font-medium">{profile.university || 'Not specified'}</p>
          </div>
          
          <div>
            <Label>Degree</Label>
            <p className="text-sm font-medium">{profile.degree || 'Not specified'}</p>
          </div>
          
          <div>
            <Label>Expected Graduation</Label>
            <p className="text-sm font-medium">{profile.graduationYear || 'Not specified'}</p>
          </div>
          
          <div>
            <Label>Skills</Label>
            <p className="text-sm font-medium">{profile.skills || 'Not specified'}</p>
          </div>
          
          <div className="md:col-span-2">
            <Label>Bio</Label>
            <p className="text-sm">{profile.bio || 'No bio provided'}</p>
          </div>
        </div>
      );
    } else {
      const profile = user.profile as EmployeeProfile;
      return (
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <Label>Name</Label>
            <p className="text-sm font-medium">{user.name}</p>
          </div>
          
          <div>
            <Label>Email</Label>
            <p className="text-sm font-medium">{user.email}</p>
          </div>
          
          <div>
            <Label>Company</Label>
            <p className="text-sm font-medium">{profile.company || 'Not specified'}</p>
          </div>
          
          <div>
            <Label>Position</Label>
            <p className="text-sm font-medium">{profile.position || 'Not specified'}</p>
          </div>
          
          <div>
            <Label>Department</Label>
            <p className="text-sm font-medium">{profile.department || 'Not specified'}</p>
          </div>
          
          <div>
            <Label>Experience</Label>
            <p className="text-sm font-medium">{profile.experience || 'Not specified'}</p>
          </div>
          
          {(profile.bio || '') && (
            <div className="md:col-span-2">
              <Label>Professional Bio</Label>
              <p className="text-sm">{profile.bio}</p>
            </div>
          )}
        </div>
      );
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center space-x-2">
              <span>Your Profile</span>
            </CardTitle>
            <CardDescription>
              {user.type === 'student' 
                ? 'This is how professionals will see your profile when considering referrals'
                : 'Your professional information'
              }
            </CardDescription>
          </div>
          
          <Dialog open={isEditing} onOpenChange={setIsEditing}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm">
                <Edit className="h-4 w-4 mr-2" />
                Edit Profile
              </Button>
            </DialogTrigger>
            
            <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Edit Profile</DialogTitle>
                <DialogDescription>
                  Update your profile information
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4">
                <div>
                  <Label htmlFor="name">Name</Label>
                  <Input
                    id="name"
                    value={editData.name}
                    onChange={(e) => setEditData(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="Your full name"
                  />
                </div>
                
                {user.type === 'student' ? renderStudentFields() : renderEmployeeFields()}
              </div>
              
              <DialogFooter className="flex space-x-2">
                <Button variant="outline" onClick={handleCancel} disabled={isLoading}>
                  <X className="h-4 w-4 mr-2" />
                  Cancel
                </Button>
                <Button onClick={handleSave} disabled={isLoading}>
                  {isLoading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                  {!isLoading && <Save className="h-4 w-4 mr-2" />}
                  Save Changes
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {renderDisplayFields()}
      </CardContent>
    </Card>
  );
}

function Label({ children }: { children: React.ReactNode }) {
  return <label className="text-sm font-medium text-muted-foreground">{children}</label>;
}