import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Loader2, LogIn } from 'lucide-react';
import { apiClient } from '../utils/api';

interface LoginDialogProps {
  onLogin: (user: any, accessToken: string) => void;
}

export function LoginDialog({ onLogin }: LoginDialogProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [credentials, setCredentials] = useState({
    email: '',
    password: ''
  });

  const handleLogin = async () => {
    setError('');
    setIsLoading(true);

    try {
      const { data, error: loginError } = await apiClient.login(credentials);

      if (loginError) {
        setError(loginError);
        setIsLoading(false);
        return;
      }

      const user = {
        id: data?.user?.id,
        type: data?.user?.userType,
        name: data?.user?.name,
        email: data?.user?.email,
        profile: data?.user?.profile
      };

      onLogin(user, data?.accessToken);
      setIsOpen(false);
      setCredentials({ email: '', password: '' });
    } catch (error) {
      console.error('Login error:', error);
      setError('An unexpected error occurred. Please try again.');
    }

    setIsLoading(false);
  };

  const canLogin = credentials.email && credentials.password;

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <LogIn className="h-4 w-4 mr-2" />
          Sign In
        </Button>
      </DialogTrigger>
      
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Sign In</DialogTitle>
          <DialogDescription>
            Enter your credentials to access your account
          </DialogDescription>
        </DialogHeader>
        
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-sm">
          <p className="font-medium text-blue-800 mb-2">Demo Credentials:</p>
          <div className="text-blue-700 space-y-1">
            <p><strong>Student:</strong> student@demo.com / demo123</p>
            <p><strong>Employee:</strong> employee@demo.com / demo123</p>
          </div>
        </div>
        
        <div className="space-y-4">
          <div>
            <Label htmlFor="login-email">Email</Label>
            <Input
              id="login-email"
              type="email"
              value={credentials.email}
              onChange={(e) => setCredentials(prev => ({ ...prev, email: e.target.value }))}
              placeholder="your.email@example.com"
            />
          </div>
          
          <div>
            <Label htmlFor="login-password">Password</Label>
            <Input
              id="login-password"
              type="password"
              value={credentials.password}
              onChange={(e) => setCredentials(prev => ({ ...prev, password: e.target.value }))}
              placeholder="Enter your password"
            />
          </div>
          
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3">
              <p className="text-sm text-red-600">{error}</p>
            </div>
          )}
          
          <Button 
            onClick={handleLogin}
            disabled={!canLogin || isLoading}
            className="w-full"
          >
            {isLoading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Sign In
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}