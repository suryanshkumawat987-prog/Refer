import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Progress } from './ui/progress';
import { ArrowLeft, Upload, User, GraduationCap, FileText, Loader2 } from 'lucide-react';
import { apiClient } from '../utils/api';

interface StudentOnboardingProps {
  onComplete: (user: any, accessToken?: string) => void;
  onBack: () => void;
}

interface StudentProfile {
  name: string;
  email: string;
  password: string;
  university: string;
  degree: string;
  graduationYear: string;
  skills: string;
  bio: string;
  resume: File | null;
}

export function StudentOnboarding({ onComplete, onBack }: StudentOnboardingProps) {
  const [step, setStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [profile, setProfile] = useState<StudentProfile>({
    name: '',
    email: '',
    password: '',
    university: '',
    degree: '',
    graduationYear: '',
    skills: '',
    bio: '',
    resume: null
  });

  const updateProfile = (field: keyof StudentProfile, value: string | File) => {
    setProfile(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleResumeUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      updateProfile('resume', file);
    }
  };

  const nextStep = async () => {
    setError('');
    
    if (step < 3) {
      setStep(step + 1);
    } else {
      // Complete onboarding - register user
      setIsLoading(true);
      
      try {
        const { data, error: registerError } = await apiClient.register({
          email: profile.email,
          password: profile.password,
          name: profile.name,
          userType: 'student',
          profile: {
            university: profile.university,
            degree: profile.degree,
            graduationYear: profile.graduationYear,
            skills: profile.skills,
            bio: profile.bio,
            resumeUploaded: !!profile.resume
          }
        });

        if (registerError) {
          setError(registerError);
          setIsLoading(false);
          return;
        }

        // If there's a resume, upload it
        let resumeUrl = null;
        if (profile.resume) {
          const { data: uploadData, error: uploadError } = await apiClient.uploadResume(profile.resume);
          if (uploadError) {
            console.error('Resume upload failed:', uploadError);
            // Continue anyway, registration was successful
          } else {
            resumeUrl = uploadData?.downloadUrl;
          }
        }

        // Now login to get access token
        const { data: loginData, error: loginError } = await apiClient.login({
          email: profile.email,
          password: profile.password
        });

        if (loginError) {
          setError('Registration successful but login failed. Please try logging in manually.');
          setIsLoading(false);
          return;
        }

        const user = {
          id: loginData?.user?.id,
          type: 'student' as const,
          name: loginData?.user?.name,
          email: loginData?.user?.email,
          profile: {
            ...loginData?.user?.profile,
            resumeUrl
          }
        };

        onComplete(user, loginData?.accessToken);
      } catch (error) {
        console.error('Registration error:', error);
        setError('An unexpected error occurred. Please try again.');
      }
      
      setIsLoading(false);
    }
  };

  const prevStep = () => {
    if (step > 1) {
      setStep(step - 1);
    } else {
      onBack();
    }
  };

  const canProceed = () => {
    switch (step) {
      case 1:
        return profile.name && profile.email && profile.password;
      case 2:
        return profile.university && profile.degree && profile.graduationYear;
      case 3:
        return profile.skills && profile.bio;
      default:
        return false;
    }
  };

  const progress = (step / 3) * 100;

  return (
    <div className="min-h-screen bg-muted/20 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <div className="flex items-center space-x-4 mb-4">
            <Button variant="ghost" size="icon" onClick={prevStep}>
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <div className="flex-1">
              <Progress value={progress} className="h-2" />
              <p className="text-sm text-muted-foreground mt-2">Step {step} of 3</p>
            </div>
          </div>
          
          <CardTitle className="flex items-center space-x-2">
            {step === 1 && <User className="h-5 w-5" />}
            {step === 2 && <GraduationCap className="h-5 w-5" />}
            {step === 3 && <FileText className="h-5 w-5" />}
            <span>
              {step === 1 && 'Personal Information'}
              {step === 2 && 'Education Details'}
              {step === 3 && 'Skills & Profile'}
            </span>
          </CardTitle>
          
          <CardDescription>
            {step === 1 && 'Tell us about yourself'}
            {step === 2 && 'Share your educational background'}
            {step === 3 && 'Highlight your skills and upload your resume'}
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-6">
          {step === 1 && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="name">Full Name</Label>
                <Input
                  id="name"
                  value={profile.name}
                  onChange={(e) => updateProfile('name', e.target.value)}
                  placeholder="Enter your full name"
                />
              </div>
              
              <div>
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  value={profile.email}
                  onChange={(e) => updateProfile('email', e.target.value)}
                  placeholder="your.email@university.edu"
                />
              </div>
              
              <div>
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={profile.password}
                  onChange={(e) => updateProfile('password', e.target.value)}
                  placeholder="Create a secure password"
                />
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="university">University/College</Label>
                <Input
                  id="university"
                  value={profile.university}
                  onChange={(e) => updateProfile('university', e.target.value)}
                  placeholder="Your university name"
                />
              </div>
              
              <div>
                <Label htmlFor="degree">Degree Program</Label>
                <Input
                  id="degree"
                  value={profile.degree}
                  onChange={(e) => updateProfile('degree', e.target.value)}
                  placeholder="e.g., Computer Science, Business Administration"
                />
              </div>
              
              <div>
                <Label htmlFor="graduationYear">Expected Graduation Year</Label>
                <Input
                  id="graduationYear"
                  value={profile.graduationYear}
                  onChange={(e) => updateProfile('graduationYear', e.target.value)}
                  placeholder="2025"
                />
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="skills">Key Skills</Label>
                <Input
                  id="skills"
                  value={profile.skills}
                  onChange={(e) => updateProfile('skills', e.target.value)}
                  placeholder="e.g., Python, React, Data Analysis, Marketing"
                />
              </div>
              
              <div>
                <Label htmlFor="bio">Brief Bio</Label>
                <Textarea
                  id="bio"
                  value={profile.bio}
                  onChange={(e) => updateProfile('bio', e.target.value)}
                  placeholder="Tell us about yourself, your interests, and career goals..."
                  className="min-h-[100px]"
                />
              </div>
              
              <div>
                <Label htmlFor="resume">Upload Resume (Optional)</Label>
                <div className="border-2 border-dashed border-border rounded-lg p-6 text-center">
                  <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                  <div>
                    <Input
                      id="resume"
                      type="file"
                      accept=".pdf,.doc,.docx"
                      onChange={handleResumeUpload}
                      className="hidden"
                    />
                    <Label htmlFor="resume" className="cursor-pointer">
                      {profile.resume ? (
                        <span className="text-primary">{profile.resume.name}</span>
                      ) : (
                        <span>Click to upload or drag and drop</span>
                      )}
                    </Label>
                    <p className="text-sm text-muted-foreground mt-1">
                      PDF, DOC, or DOCX up to 10MB
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3">
              <p className="text-sm text-red-600">{error}</p>
            </div>
          )}

          <div className="flex justify-between pt-6">
            <Button variant="outline" onClick={prevStep} disabled={isLoading}>
              {step === 1 ? 'Back to Home' : 'Previous'}
            </Button>
            
            <Button 
              onClick={nextStep}
              disabled={!canProceed() || isLoading}
            >
              {isLoading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              {step === 3 ? 'Complete Profile' : 'Next'}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}