import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from './ui/dialog';
import { 
  Building, 
  LogOut, 
  Users, 
  CheckCircle, 
  Clock, 
  ExternalLink,
  User,
  GraduationCap,
  FileText,
  ThumbsUp,
  ThumbsDown,
  Loader2
} from 'lucide-react';
import { apiClient } from '../utils/api';
import { ProfileEditor } from './ProfileEditor';

interface User {
  id: string;
  type: 'employee';
  name: string;
  email: string;
  profile: any;
}

interface PendingApplication {
  id: string;
  jobTitle: string;
  company: string;
  jobUrl: string;
  description: string;
  status: string;
  appliedDate: string;
  student: {
    name: string;
    email: string;
    profile: {
      university: string;
      degree: string;
      graduationYear: string;
      skills: string;
      bio: string;
    };
  };
}

interface EmployeeDashboardProps {
  user: User;
  onLogout: () => void;
}

export function EmployeeDashboard({ user, onLogout }: EmployeeDashboardProps) {
  const [currentUser, setCurrentUser] = useState<User>(user);
  const [pendingApplications, setPendingApplications] = useState<PendingApplication[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isReferring, setIsReferring] = useState(false);

  // Load applications on component mount
  useEffect(() => {
    loadApplications();
  }, []);

  const loadApplications = async () => {
    try {
      const { data, error } = await apiClient.getCompanyApplications();
      if (error) {
        console.error('Failed to load applications:', error);
      } else {
        setPendingApplications(data?.applications || []);
      }
    } catch (error) {
      console.error('Error loading applications:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const [referredApplications, setReferredApplications] = useState<PendingApplication[]>([]);
  const [selectedApplication, setSelectedApplication] = useState<PendingApplication | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const handleProfileUpdate = (updatedUser: User) => {
    setCurrentUser(updatedUser);
    // Update localStorage to persist the changes
    localStorage.setItem('referral_user', JSON.stringify(updatedUser));
  };

  const handleApplicationClick = (application: PendingApplication) => {
    setSelectedApplication(application);
    setIsDialogOpen(true);
  };

  const handleRefer = async () => {
    if (selectedApplication) {
      setIsReferring(true);
      
      try {
        const { data, error } = await apiClient.referStudent(selectedApplication.id);
        
        if (error) {
          console.error('Failed to refer student:', error);
          alert('Failed to refer student. Please try again.');
        } else {
          // Move application to referred list
          setReferredApplications(prev => [...prev, selectedApplication]);
          setPendingApplications(prev => prev.filter(app => app.id !== selectedApplication.id));
          setIsDialogOpen(false);
          setSelectedApplication(null);
        }
      } catch (error) {
        console.error('Error referring student:', error);
        alert('An unexpected error occurred. Please try again.');
      }
      
      setIsReferring(false);
    }
  };

  const handleReject = () => {
    setIsDialogOpen(false);
    setSelectedApplication(null);
  };

  const isFromMyCompany = (application: PendingApplication) => {
    // Simple check - match applications for this user's company
    return application.company.toLowerCase() === currentUser.profile.company.toLowerCase();
  };

  const applicationsForMyCompany = pendingApplications.filter(isFromMyCompany);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Building className="h-5 w-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-lg font-semibold">Employee Dashboard</h1>
              <p className="text-sm text-muted-foreground">Welcome back, {currentUser.name}</p>
            </div>
          </div>
          
          <Button variant="ghost" onClick={onLogout}>
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Stats Cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Pending Reviews</p>
                  <p className="text-2xl font-bold">{applicationsForMyCompany.length}</p>
                </div>
                <Clock className="h-8 w-8 text-yellow-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Students Referred</p>
                  <p className="text-2xl font-bold text-green-600">{referredApplications.length}</p>
                </div>
                <CheckCircle className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Company</p>
                  <p className="text-lg font-semibold">{currentUser.profile.company}</p>
                </div>
                <Building className="h-8 w-8 text-muted-foreground" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="pending" className="space-y-6">
          <TabsList>
            <TabsTrigger value="pending">
              Pending Applications ({applicationsForMyCompany.length})
            </TabsTrigger>
            <TabsTrigger value="referred">
              Referred Students ({referredApplications.length})
            </TabsTrigger>
            <TabsTrigger value="profile">My Profile</TabsTrigger>
          </TabsList>

          <TabsContent value="pending" className="space-y-4">
            {isLoading ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <Loader2 className="h-8 w-8 mx-auto mb-4 animate-spin text-muted-foreground" />
                  <p className="text-muted-foreground">Loading applications...</p>
                </CardContent>
              </Card>
            ) : applicationsForMyCompany.length === 0 ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <Users className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-lg font-semibold mb-2">No pending applications</h3>
                  <p className="text-muted-foreground">
                    There are currently no student applications for {currentUser.profile.company} positions
                  </p>
                </CardContent>
              </Card>
            ) : (
              applicationsForMyCompany.map((application) => (
                <Card 
                  key={application.id} 
                  className="cursor-pointer hover:shadow-md transition-shadow"
                  onClick={() => handleApplicationClick(application)}
                >
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <h3 className="text-lg font-semibold">{application.student.name}</h3>
                          <Badge variant="secondary">{application.student.profile.university}</Badge>
                        </div>
                        
                        <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-3">
                          <span>{application.student.profile.degree}</span>
                          <span>Class of {application.student.profile.graduationYear}</span>
                          <span>Applied {new Date(application.appliedDate).toLocaleDateString()}</span>
                        </div>
                        
                        <p className="text-sm font-medium mb-2">Applying for: {application.jobTitle}</p>
                        <p className="text-sm text-muted-foreground mb-3">Skills: {application.student.profile.skills}</p>
                        <p className="text-sm line-clamp-2">{application.student.profile.bio}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>

          <TabsContent value="referred" className="space-y-4">
            {referredApplications.length === 0 ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <CheckCircle className="h-12 w-12 mx-auto mb-4 text-green-600" />
                  <h3 className="text-lg font-semibold mb-2">No referrals yet</h3>
                  <p className="text-muted-foreground">
                    Students you refer will appear here
                  </p>
                </CardContent>
              </Card>
            ) : (
              referredApplications.map((application) => (
                <Card key={application.id}>
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <h3 className="text-lg font-semibold">{application.student.name}</h3>
                          <Badge className="bg-green-100 text-green-800">Referred</Badge>
                        </div>
                        
                        <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-2">
                          <span>{application.student.profile.university}</span>
                          <span>{application.student.profile.degree}</span>
                        </div>
                        
                        <p className="text-sm font-medium">Applied for: {application.jobTitle}</p>
                      </div>
                      
                      <a 
                        href={application.jobUrl} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="flex items-center space-x-1 text-primary hover:underline text-sm"
                      >
                        <span>View Job</span>
                        <ExternalLink className="h-3 w-3" />
                      </a>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>

          <TabsContent value="profile">
            <ProfileEditor 
              user={currentUser} 
              onProfileUpdate={handleProfileUpdate}
            />
          </TabsContent>
        </Tabs>
      </div>

      {/* Application Review Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          {selectedApplication && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center space-x-2">
                  <GraduationCap className="h-5 w-5" />
                  <span>{selectedApplication.student.name}</span>
                </DialogTitle>
                <DialogDescription>
                  Review this student's application for referral
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-6">
                {/* Student Info */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>University</Label>
                    <p className="text-sm font-medium">{selectedApplication.student.profile.university}</p>
                  </div>
                  <div>
                    <Label>Degree</Label>
                    <p className="text-sm font-medium">{selectedApplication.student.profile.degree}</p>
                  </div>
                  <div>
                    <Label>Graduation Year</Label>
                    <p className="text-sm font-medium">{selectedApplication.student.profile.graduationYear}</p>
                  </div>
                  <div>
                    <Label>Email</Label>
                    <p className="text-sm font-medium">{selectedApplication.student.email}</p>
                  </div>
                </div>
                
                {/* Skills */}
                <div>
                  <Label>Skills</Label>
                  <p className="text-sm">{selectedApplication.student.profile.skills}</p>
                </div>
                
                {/* Bio */}
                <div>
                  <Label>Student Bio</Label>
                  <p className="text-sm">{selectedApplication.student.profile.bio}</p>
                </div>
                
                {/* Job Application */}
                <div className="border-t pt-4">
                  <Label>Applying for</Label>
                  <div className="flex items-center justify-between mt-2">
                    <p className="text-sm font-medium">{selectedApplication.jobTitle}</p>
                    <a 
                      href={selectedApplication.jobUrl} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="flex items-center space-x-1 text-primary hover:underline text-sm"
                    >
                      <span>View Job Posting</span>
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  </div>
                  
                  <div className="mt-4">
                    <Label>Why they're interested</Label>
                    <p className="text-sm mt-1">{selectedApplication.description}</p>
                  </div>
                </div>
              </div>
              
              <DialogFooter className="flex space-x-2">
                <Button variant="outline" onClick={handleReject} disabled={isReferring}>
                  <ThumbsDown className="h-4 w-4 mr-2" />
                  Pass
                </Button>
                <Button onClick={handleRefer} disabled={isReferring}>
                  {isReferring && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                  {!isReferring && <ThumbsUp className="h-4 w-4 mr-2" />}
                  Refer This Student
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Label({ children }: { children: React.ReactNode }) {
  return <label className="text-sm font-medium text-muted-foreground">{children}</label>;
}