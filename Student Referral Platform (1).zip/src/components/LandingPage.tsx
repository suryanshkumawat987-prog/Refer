import { Button } from './ui/button';
import { Card } from './ui/card';
import { Users, Briefcase, Star, TrendingUp } from 'lucide-react';
import { LoginDialog } from './LoginDialog';

interface LandingPageProps {
  onNavigate: (page: 'student-onboarding' | 'employee-onboarding') => void;
  onLogin: (user: any, accessToken: string) => void;
}

export function LandingPage({ onNavigate, onLogin }: LandingPageProps) {
  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="border-b border-border/50 bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Users className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-semibold">ReferralConnect</span>
          </div>
          
          <div className="flex items-center space-x-4">
            <LoginDialog onLogin={onLogin} />
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-16 text-center">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
            Land Your Dream Job Through Referrals
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Connect talented students with professionals who can refer them for job openings. 
            Make the hiring process fairer and reduce job hunting stress.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button 
              size="lg" 
              className="w-full sm:w-auto"
              onClick={() => onNavigate('student-onboarding')}
            >
              I'm a Student
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="w-full sm:w-auto"
              onClick={() => onNavigate('employee-onboarding')}
            >
              I'm a Professional
            </Button>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="bg-muted/30 py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">How It Works</h2>
          
          <div className="grid md:grid-cols-2 gap-12 max-w-4xl mx-auto">
            {/* For Students */}
            <div>
              <h3 className="text-xl font-semibold mb-6 text-center">For Students</h3>
              <div className="space-y-4">
                {[
                  { step: '1', title: 'Create Your Profile', desc: 'Upload your resume and showcase your skills' },
                  { step: '2', title: 'Submit Job Applications', desc: 'Paste job links you want to apply for' },
                  { step: '3', title: 'Get Referred', desc: 'Professionals review and refer qualified candidates' },
                  { step: '4', title: 'Land Interviews', desc: 'Increase your chances with insider referrals' }
                ].map((item) => (
                  <div key={item.step} className="flex items-start space-x-4">
                    <div className="w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm font-semibold">
                      {item.step}
                    </div>
                    <div>
                      <h4 className="font-medium">{item.title}</h4>
                      <p className="text-sm text-muted-foreground">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* For Professionals */}
            <div>
              <h3 className="text-xl font-semibold mb-6 text-center">For Professionals</h3>
              <div className="space-y-4">
                {[
                  { step: '1', title: 'Join the Platform', desc: 'Verify your company email and create profile' },
                  { step: '2', title: 'Review Applications', desc: 'Browse student profiles for your company' },
                  { step: '3', title: 'Choose to Refer', desc: 'Select promising candidates to refer' },
                  { step: '4', title: 'Help Talent Grow', desc: 'Be part of building future careers' }
                ].map((item) => (
                  <div key={item.step} className="flex items-start space-x-4">
                    <div className="w-8 h-8 bg-secondary text-secondary-foreground rounded-full flex items-center justify-center text-sm font-semibold">
                      {item.step}
                    </div>
                    <div>
                      <h4 className="font-medium">{item.title}</h4>
                      <p className="text-sm text-muted-foreground">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Why ReferralConnect?</h2>
          
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <Card className="p-6 text-center border-border/50">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Higher Success Rate</h3>
              <p className="text-muted-foreground">Referred candidates are 5x more likely to get hired than traditional applications</p>
            </Card>

            <Card className="p-6 text-center border-border/50">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Briefcase className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Quality Opportunities</h3>
              <p className="text-muted-foreground">Access jobs from verified professionals at top companies</p>
            </Card>

            <Card className="p-6 text-center border-border/50">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Star className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Fair & Transparent</h3>
              <p className="text-muted-foreground">Merit-based referrals that level the playing field for all students</p>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/50 bg-muted/30 py-8">
        <div className="container mx-auto px-4 text-center">
          <p className="text-muted-foreground">
            © 2024 ReferralConnect. Making job referrals accessible for everyone.
          </p>
        </div>
      </footer>
    </div>
  );
}