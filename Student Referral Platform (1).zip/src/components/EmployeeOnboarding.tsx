import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Progress } from './ui/progress';
import { ArrowLeft, Building, User, Briefcase, Loader2 } from 'lucide-react';
import { apiClient } from '../utils/api';

interface EmployeeOnboardingProps {
  onComplete: (user: any, accessToken?: string) => void;
  onBack: () => void;
}

interface EmployeeProfile {
  name: string;
  email: string;
  password: string;
  company: string;
  position: string;
  department: string;
  experience: string;
  bio: string;
}

export function EmployeeOnboarding({ onComplete, onBack }: EmployeeOnboardingProps) {
  const [step, setStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [profile, setProfile] = useState<EmployeeProfile>({
    name: '',
    email: '',
    password: '',
    company: '',
    position: '',
    department: '',
    experience: '',
    bio: ''
  });

  const updateProfile = (field: keyof EmployeeProfile, value: string) => {
    setProfile(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const nextStep = async () => {
    setError('');
    
    if (step < 3) {
      setStep(step + 1);
    } else {
      // Complete onboarding - register user
      setIsLoading(true);
      
      try {
        const { data, error: registerError } = await apiClient.register({
          email: profile.email,
          password: profile.password,
          name: profile.name,
          userType: 'employee',
          profile: {
            company: profile.company,
            position: profile.position,
            department: profile.department,
            experience: profile.experience,
            bio: profile.bio
          }
        });

        if (registerError) {
          setError(registerError);
          setIsLoading(false);
          return;
        }

        // Now login to get access token
        const { data: loginData, error: loginError } = await apiClient.login({
          email: profile.email,
          password: profile.password
        });

        if (loginError) {
          setError('Registration successful but login failed. Please try logging in manually.');
          setIsLoading(false);
          return;
        }

        const user = {
          id: loginData?.user?.id,
          type: 'employee' as const,
          name: loginData?.user?.name,
          email: loginData?.user?.email,
          profile: loginData?.user?.profile
        };

        onComplete(user, loginData?.accessToken);
      } catch (error) {
        console.error('Registration error:', error);
        setError('An unexpected error occurred. Please try again.');
      }
      
      setIsLoading(false);
    }
  };

  const prevStep = () => {
    if (step > 1) {
      setStep(step - 1);
    } else {
      onBack();
    }
  };

  const canProceed = () => {
    switch (step) {
      case 1:
        return profile.name && profile.email && profile.password;
      case 2:
        return profile.company && profile.position;
      case 3:
        return profile.department && profile.experience;
      default:
        return false;
    }
  };

  const progress = (step / 3) * 100;

  return (
    <div className="min-h-screen bg-muted/20 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <div className="flex items-center space-x-4 mb-4">
            <Button variant="ghost" size="icon" onClick={prevStep}>
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <div className="flex-1">
              <Progress value={progress} className="h-2" />
              <p className="text-sm text-muted-foreground mt-2">Step {step} of 3</p>
            </div>
          </div>
          
          <CardTitle className="flex items-center space-x-2">
            {step === 1 && <User className="h-5 w-5" />}
            {step === 2 && <Building className="h-5 w-5" />}
            {step === 3 && <Briefcase className="h-5 w-5" />}
            <span>
              {step === 1 && 'Personal Information'}
              {step === 2 && 'Company Details'}
              {step === 3 && 'Professional Background'}
            </span>
          </CardTitle>
          
          <CardDescription>
            {step === 1 && 'Tell us about yourself'}
            {step === 2 && 'Verify your company information'}
            {step === 3 && 'Share your professional experience'}
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-6">
          {step === 1 && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="name">Full Name</Label>
                <Input
                  id="name"
                  value={profile.name}
                  onChange={(e) => updateProfile('name', e.target.value)}
                  placeholder="Enter your full name"
                />
              </div>
              
              <div>
                <Label htmlFor="email">Work Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  value={profile.email}
                  onChange={(e) => updateProfile('email', e.target.value)}
                  placeholder="your.email@company.com"
                />
                <p className="text-sm text-muted-foreground mt-1">
                  Please use your official company email for verification
                </p>
              </div>
              
              <div>
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={profile.password}
                  onChange={(e) => updateProfile('password', e.target.value)}
                  placeholder="Create a secure password"
                />
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="company">Company Name</Label>
                <Input
                  id="company"
                  value={profile.company}
                  onChange={(e) => updateProfile('company', e.target.value)}
                  placeholder="Your company name"
                />
              </div>
              
              <div>
                <Label htmlFor="position">Job Title/Position</Label>
                <Input
                  id="position"
                  value={profile.position}
                  onChange={(e) => updateProfile('position', e.target.value)}
                  placeholder="e.g., Software Engineer, Marketing Manager"
                />
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="department">Department</Label>
                <Input
                  id="department"
                  value={profile.department}
                  onChange={(e) => updateProfile('department', e.target.value)}
                  placeholder="e.g., Engineering, Marketing, Sales"
                />
              </div>
              
              <div>
                <Label htmlFor="experience">Years of Experience</Label>
                <Input
                  id="experience"
                  value={profile.experience}
                  onChange={(e) => updateProfile('experience', e.target.value)}
                  placeholder="e.g., 3 years"
                />
              </div>
              
              <div>
                <Label htmlFor="bio">Professional Bio (Optional)</Label>
                <Textarea
                  id="bio"
                  value={profile.bio}
                  onChange={(e) => updateProfile('bio', e.target.value)}
                  placeholder="Tell us about your role, expertise, and what kind of referrals you'd like to provide..."
                  className="min-h-[100px]"
                />
              </div>
            </div>
          )}

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3">
              <p className="text-sm text-red-600">{error}</p>
            </div>
          )}

          <div className="flex justify-between pt-6">
            <Button variant="outline" onClick={prevStep} disabled={isLoading}>
              {step === 1 ? 'Back to Home' : 'Previous'}
            </Button>
            
            <Button 
              onClick={nextStep}
              disabled={!canProceed() || isLoading}
            >
              {isLoading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              {step === 3 ? 'Complete Profile' : 'Next'}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}