import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { 
  Plus, 
  ExternalLink, 
  Clock, 
  CheckCircle, 
  XCircle, 
  User, 
  LogOut,
  Briefcase,
  FileText,
  Send,
  Loader2
} from 'lucide-react';
import { apiClient } from '../utils/api';
import { ProfileEditor } from './ProfileEditor';

interface User {
  id: string;
  type: 'student';
  name: string;
  email: string;
  profile: any;
}

interface JobApplication {
  id: string;
  jobTitle: string;
  company: string;
  jobUrl: string;
  description: string;
  status: 'pending' | 'referred' | 'rejected';
  appliedDate: string;
  referredBy?: string;
}

interface StudentDashboardProps {
  user: User;
  onLogout: () => void;
}

export function StudentDashboard({ user, onLogout }: StudentDashboardProps) {
  const [currentUser, setCurrentUser] = useState<User>(user);
  const [applications, setApplications] = useState<JobApplication[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Load applications on component mount
  useEffect(() => {
    loadApplications();
  }, []);

  const loadApplications = async () => {
    try {
      const { data, error } = await apiClient.getStudentApplications();
      if (error) {
        console.error('Failed to load applications:', error);
      } else {
        setApplications(data?.applications || []);
      }
    } catch (error) {
      console.error('Error loading applications:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const [newApplication, setNewApplication] = useState({
    jobTitle: '',
    company: '',
    jobUrl: '',
    description: ''
  });

  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const handleProfileUpdate = (updatedUser: User) => {
    setCurrentUser(updatedUser);
    // Update localStorage to persist the changes
    localStorage.setItem('referral_user', JSON.stringify(updatedUser));
  };

  const submitApplication = async () => {
    if (newApplication.jobTitle && newApplication.company && newApplication.jobUrl) {
      setIsSubmitting(true);
      
      try {
        const { data, error } = await apiClient.submitApplication(newApplication);
        
        if (error) {
          console.error('Failed to submit application:', error);
          alert('Failed to submit application. Please try again.');
        } else {
          // Add the new application to the list
          const application: JobApplication = {
            id: data?.application?.id,
            jobTitle: data?.application?.jobTitle,
            company: data?.application?.company,
            jobUrl: data?.application?.jobUrl,
            description: data?.application?.description,
            status: data?.application?.status,
            appliedDate: data?.application?.appliedDate?.split('T')[0]
          };
          
          setApplications(prev => [application, ...prev]);
          setNewApplication({ jobTitle: '', company: '', jobUrl: '', description: '' });
          setIsDialogOpen(false);
        }
      } catch (error) {
        console.error('Error submitting application:', error);
        alert('An unexpected error occurred. Please try again.');
      }
      
      setIsSubmitting(false);
    }
  };

  const getStatusColor = (status: JobApplication['status']) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'referred': return 'bg-green-100 text-green-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: JobApplication['status']) => {
    switch (status) {
      case 'pending': return <Clock className="h-4 w-4" />;
      case 'referred': return <CheckCircle className="h-4 w-4" />;
      case 'rejected': return <XCircle className="h-4 w-4" />;
      default: return <Clock className="h-4 w-4" />;
    }
  };

  const pendingCount = applications.filter(app => app.status === 'pending').length;
  const referredCount = applications.filter(app => app.status === 'referred').length;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Briefcase className="h-5 w-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-lg font-semibold">Student Dashboard</h1>
              <p className="text-sm text-muted-foreground">Welcome back, {currentUser.name}</p>
            </div>
          </div>
          
          <Button variant="ghost" onClick={onLogout}>
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Stats Cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Applications</p>
                  <p className="text-2xl font-bold">{applications.length}</p>
                </div>
                <FileText className="h-8 w-8 text-muted-foreground" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Pending Review</p>
                  <p className="text-2xl font-bold text-yellow-600">{pendingCount}</p>
                </div>
                <Clock className="h-8 w-8 text-yellow-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Referrals Received</p>
                  <p className="text-2xl font-bold text-green-600">{referredCount}</p>
                </div>
                <CheckCircle className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="applications" className="space-y-6">
          <div className="flex items-center justify-between">
            <TabsList>
              <TabsTrigger value="applications">My Applications</TabsTrigger>
              <TabsTrigger value="profile">Profile</TabsTrigger>
            </TabsList>

            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Submit New Application
                </Button>
              </DialogTrigger>
              
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>Submit Job Application</DialogTitle>
                  <DialogDescription>
                    Paste a job link and tell us why you're interested in this role
                  </DialogDescription>
                </DialogHeader>
                
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="jobTitle">Job Title</Label>
                    <Input
                      id="jobTitle"
                      value={newApplication.jobTitle}
                      onChange={(e) => setNewApplication(prev => ({...prev, jobTitle: e.target.value}))}
                      placeholder="e.g., Software Engineering Intern"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="company">Company</Label>
                    <Input
                      id="company"
                      value={newApplication.company}
                      onChange={(e) => setNewApplication(prev => ({...prev, company: e.target.value}))}
                      placeholder="e.g., Google, Microsoft"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="jobUrl">Job Posting URL</Label>
                    <Input
                      id="jobUrl"
                      value={newApplication.jobUrl}
                      onChange={(e) => setNewApplication(prev => ({...prev, jobUrl: e.target.value}))}
                      placeholder="https://careers.company.com/job/12345"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="description">Why are you interested?</Label>
                    <Textarea
                      id="description"
                      value={newApplication.description}
                      onChange={(e) => setNewApplication(prev => ({...prev, description: e.target.value}))}
                      placeholder="Explain why you're interested in this role and what makes you a good fit..."
                      className="min-h-[80px]"
                    />
                  </div>
                  
                  <Button 
                    onClick={submitApplication} 
                    className="w-full"
                    disabled={!newApplication.jobTitle || !newApplication.company || !newApplication.jobUrl || isSubmitting}
                  >
                    {isSubmitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                    {!isSubmitting && <Send className="h-4 w-4 mr-2" />}
                    Submit Application
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <TabsContent value="applications" className="space-y-4">
            {isLoading ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <Loader2 className="h-8 w-8 mx-auto mb-4 animate-spin text-muted-foreground" />
                  <p className="text-muted-foreground">Loading your applications...</p>
                </CardContent>
              </Card>
            ) : applications.length === 0 ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <Briefcase className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-lg font-semibold mb-2">No applications yet</h3>
                  <p className="text-muted-foreground mb-4">
                    Start by submitting your first job application to get referrals from professionals
                  </p>
                  <Button onClick={() => setIsDialogOpen(true)}>
                    <Plus className="h-4 w-4 mr-2" />
                    Submit Your First Application
                  </Button>
                </CardContent>
              </Card>
            ) : (
              applications.map((application) => (
                <Card key={application.id}>
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <h3 className="text-lg font-semibold">{application.jobTitle}</h3>
                          <Badge variant="secondary">{application.company}</Badge>
                        </div>
                        
                        <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-3">
                          <span>Applied on {new Date(application.appliedDate).toLocaleDateString()}</span>
                          <a 
                            href={application.jobUrl} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="flex items-center space-x-1 text-primary hover:underline"
                          >
                            <span>View Job</span>
                            <ExternalLink className="h-3 w-3" />
                          </a>
                        </div>
                        
                        <p className="text-sm mb-4">{application.description}</p>
                        
                        {application.referredBy && (
                          <p className="text-sm text-green-600">
                            ✓ Referred by {application.referredBy}
                          </p>
                        )}
                      </div>
                      
                      <Badge className={getStatusColor(application.status)}>
                        <div className="flex items-center space-x-1">
                          {getStatusIcon(application.status)}
                          <span className="capitalize">{application.status}</span>
                        </div>
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>

          <TabsContent value="profile">
            <ProfileEditor 
              user={currentUser} 
              onProfileUpdate={handleProfileUpdate}
            />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}