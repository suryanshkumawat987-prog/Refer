import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import { createClient } from 'npm:@supabase/supabase-js';
import * as kv from './kv_store.tsx';

const app = new Hono();

// Middleware
app.use('*', cors());
app.use('*', logger(console.log));

// Create Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

// Initialize storage bucket
const bucketName = 'make-9a7a8433-referral-resumes';

// Check and create bucket if it doesn't exist
const { data: buckets } = await supabase.storage.listBuckets();
const bucketExists = buckets?.some(bucket => bucket.name === bucketName);
if (!bucketExists) {
  await supabase.storage.createBucket(bucketName, { public: false });
  console.log(`Created bucket: ${bucketName}`);
}

// Helper function to verify user authentication
async function verifyUser(request: Request) {
  const accessToken = request.headers.get('Authorization')?.split(' ')[1];
  if (!accessToken) {
    return { error: 'No access token provided', user: null };
  }
  
  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  if (error || !user?.id) {
    return { error: 'Invalid or expired token', user: null };
  }
  
  return { error: null, user };
}

// User Registration
app.post('/make-server-9a7a8433/register', async (c) => {
  try {
    const { email, password, name, userType, profile } = await c.req.json();
    
    if (!email || !password || !name || !userType) {
      return c.json({ error: 'Missing required fields' }, 400);
    }

    // Create user in Supabase Auth
    const { data: authData, error: authError } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name, userType },
      // Automatically confirm the user's email since an email server hasn't been configured
      email_confirm: true
    });

    if (authError) {
      console.log('Registration error:', authError);
      return c.json({ error: `Registration failed: ${authError.message}` }, 400);
    }

    const userId = authData.user.id;

    // Store user profile in KV store
    const userProfile = {
      id: userId,
      name,
      email,
      userType,
      profile,
      createdAt: new Date().toISOString()
    };

    await kv.set(`user:${userId}`, userProfile);
    await kv.set(`user_email:${email}`, userId);

    return c.json({ 
      user: {
        id: userId,
        name,
        email,
        userType
      }
    });
  } catch (error) {
    console.log('Registration server error:', error);
    return c.json({ error: 'Internal server error during registration' }, 500);
  }
});

// User Login
app.post('/make-server-9a7a8433/login', async (c) => {
  try {
    const { email, password } = await c.req.json();
    
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_ANON_KEY')!
    );

    const { data, error } = await supabaseClient.auth.signInWithPassword({
      email,
      password
    });

    if (error) {
      console.log('Login error:', error);
      return c.json({ error: `Login failed: ${error.message}` }, 401);
    }

    const userId = data.user.id;
    const userProfile = await kv.get(`user:${userId}`);

    if (!userProfile) {
      return c.json({ error: 'User profile not found' }, 404);
    }

    return c.json({
      user: {
        id: userId,
        name: userProfile.name,
        email: userProfile.email,
        userType: userProfile.userType,
        profile: userProfile.profile
      },
      accessToken: data.session.access_token
    });
  } catch (error) {
    console.log('Login server error:', error);
    return c.json({ error: 'Internal server error during login' }, 500);
  }
});

// Submit Job Application
app.post('/make-server-9a7a8433/applications', async (c) => {
  try {
    const { error: authError, user } = await verifyUser(c.req.raw);
    if (authError || !user) {
      return c.json({ error: authError || 'Unauthorized' }, 401);
    }

    const { jobTitle, company, jobUrl, description } = await c.req.json();
    
    if (!jobTitle || !company || !jobUrl) {
      return c.json({ error: 'Missing required application fields' }, 400);
    }

    const applicationId = `app_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    const application = {
      id: applicationId,
      studentId: user.id,
      jobTitle,
      company,
      jobUrl,
      description,
      status: 'pending',
      appliedDate: new Date().toISOString(),
      createdAt: new Date().toISOString()
    };

    await kv.set(`application:${applicationId}`, application);
    await kv.set(`student_applications:${user.id}:${applicationId}`, applicationId);
    await kv.set(`company_applications:${company.toLowerCase()}:${applicationId}`, applicationId);

    return c.json({ application });
  } catch (error) {
    console.log('Application submission error:', error);
    return c.json({ error: 'Failed to submit application' }, 500);
  }
});

// Get Student Applications
app.get('/make-server-9a7a8433/applications/student', async (c) => {
  try {
    const { error: authError, user } = await verifyUser(c.req.raw);
    if (authError || !user) {
      return c.json({ error: authError || 'Unauthorized' }, 401);
    }

    const applicationIds = await kv.getByPrefix(`student_applications:${user.id}:`);
    const applications = [];

    for (const appId of applicationIds) {
      const application = await kv.get(`application:${appId}`);
      if (application) {
        applications.push(application);
      }
    }

    // Sort by most recent first
    applications.sort((a, b) => new Date(b.appliedDate).getTime() - new Date(a.appliedDate).getTime());

    return c.json({ applications });
  } catch (error) {
    console.log('Get student applications error:', error);
    return c.json({ error: 'Failed to retrieve applications' }, 500);
  }
});

// Get Applications for Employee's Company
app.get('/make-server-9a7a8433/applications/company', async (c) => {
  try {
    const { error: authError, user } = await verifyUser(c.req.raw);
    if (authError || !user) {
      return c.json({ error: authError || 'Unauthorized' }, 401);
    }

    // Get employee profile to find their company
    const employeeProfile = await kv.get(`user:${user.id}`);
    if (!employeeProfile || employeeProfile.userType !== 'employee') {
      return c.json({ error: 'Unauthorized - employees only' }, 403);
    }

    const company = employeeProfile.profile.company.toLowerCase();
    const applicationIds = await kv.getByPrefix(`company_applications:${company}:`);
    const applications = [];

    for (const appId of applicationIds) {
      const application = await kv.get(`application:${appId}`);
      if (application && application.status === 'pending') {
        // Get student profile
        const studentProfile = await kv.get(`user:${application.studentId}`);
        if (studentProfile) {
          applications.push({
            ...application,
            student: {
              name: studentProfile.name,
              email: studentProfile.email,
              profile: studentProfile.profile
            }
          });
        }
      }
    }

    // Sort by most recent first
    applications.sort((a, b) => new Date(b.appliedDate).getTime() - new Date(a.appliedDate).getTime());

    return c.json({ applications });
  } catch (error) {
    console.log('Get company applications error:', error);
    return c.json({ error: 'Failed to retrieve company applications' }, 500);
  }
});

// Refer a Student
app.post('/make-server-9a7a8433/applications/:applicationId/refer', async (c) => {
  try {
    const { error: authError, user } = await verifyUser(c.req.raw);
    if (authError || !user) {
      return c.json({ error: authError || 'Unauthorized' }, 401);
    }

    const applicationId = c.req.param('applicationId');
    const application = await kv.get(`application:${applicationId}`);
    
    if (!application) {
      return c.json({ error: 'Application not found' }, 404);
    }

    // Get employee profile
    const employeeProfile = await kv.get(`user:${user.id}`);
    if (!employeeProfile || employeeProfile.userType !== 'employee') {
      return c.json({ error: 'Unauthorized - employees only' }, 403);
    }

    // Update application status
    const updatedApplication = {
      ...application,
      status: 'referred',
      referredBy: employeeProfile.name,
      referredById: user.id,
      referredDate: new Date().toISOString()
    };

    await kv.set(`application:${applicationId}`, updatedApplication);

    return c.json({ application: updatedApplication });
  } catch (error) {
    console.log('Referral error:', error);
    return c.json({ error: 'Failed to refer student' }, 500);
  }
});

// Upload Resume
app.post('/make-server-9a7a8433/upload-resume', async (c) => {
  try {
    const { error: authError, user } = await verifyUser(c.req.raw);
    if (authError || !user) {
      return c.json({ error: authError || 'Unauthorized' }, 401);
    }

    const formData = await c.req.formData();
    const file = formData.get('resume') as File;
    
    if (!file) {
      return c.json({ error: 'No file provided' }, 400);
    }

    const fileExt = file.name.split('.').pop();
    const fileName = `${user.id}_${Date.now()}.${fileExt}`;
    
    const { data, error } = await supabase.storage
      .from(bucketName)
      .upload(fileName, file);

    if (error) {
      console.log('Resume upload error:', error);
      return c.json({ error: 'Failed to upload resume' }, 500);
    }

    // Get signed URL for the uploaded file
    const { data: signedUrlData } = await supabase.storage
      .from(bucketName)
      .createSignedUrl(fileName, 3600); // 1 hour expiry

    return c.json({ 
      fileName: file.name,
      filePath: data.path,
      downloadUrl: signedUrlData?.signedUrl
    });
  } catch (error) {
    console.log('Resume upload server error:', error);
    return c.json({ error: 'Failed to process resume upload' }, 500);
  }
});

// Get User Profile
app.get('/make-server-9a7a8433/profile', async (c) => {
  try {
    const { error: authError, user } = await verifyUser(c.req.raw);
    if (authError || !user) {
      return c.json({ error: authError || 'Unauthorized' }, 401);
    }

    const userProfile = await kv.get(`user:${user.id}`);
    if (!userProfile) {
      return c.json({ error: 'Profile not found' }, 404);
    }

    return c.json({ profile: userProfile });
  } catch (error) {
    console.log('Get profile error:', error);
    return c.json({ error: 'Failed to retrieve profile' }, 500);
  }
});

// Update User Profile
app.put('/make-server-9a7a8433/profile', async (c) => {
  try {
    const { error: authError, user } = await verifyUser(c.req.raw);
    if (authError || !user) {
      return c.json({ error: authError || 'Unauthorized' }, 401);
    }

    const { name, profile } = await c.req.json();
    
    if (!name || !profile) {
      return c.json({ error: 'Missing required fields: name and profile' }, 400);
    }

    // Get existing user profile
    const existingProfile = await kv.get(`user:${user.id}`);
    if (!existingProfile) {
      return c.json({ error: 'Profile not found' }, 404);
    }

    // Update the profile
    const updatedProfile = {
      ...existingProfile,
      name,
      profile,
      updatedAt: new Date().toISOString()
    };

    await kv.set(`user:${user.id}`, updatedProfile);

    return c.json({ 
      user: {
        id: user.id,
        name: updatedProfile.name,
        email: updatedProfile.email,
        userType: updatedProfile.userType,
        profile: updatedProfile.profile
      }
    });
  } catch (error) {
    console.log('Update profile error:', error);
    return c.json({ error: 'Failed to update profile' }, 500);
  }
});

// Demo data initialization
app.post('/make-server-9a7a8433/init-demo', async (c) => {
  try {
    // Create a demo student
    const studentEmail = 'student@demo.com';
    const studentPassword = 'demo123';
    
    const { data: studentAuth, error: studentError } = await supabase.auth.admin.createUser({
      email: studentEmail,
      password: studentPassword,
      user_metadata: { name: 'Demo Student', userType: 'student' },
      email_confirm: true
    });

    if (!studentError && studentAuth.user) {
      await kv.set(`user:${studentAuth.user.id}`, {
        id: studentAuth.user.id,
        name: 'Demo Student',
        email: studentEmail,
        userType: 'student',
        profile: {
          university: 'Demo University',
          degree: 'Computer Science', 
          graduationYear: '2025',
          skills: 'React, Python, JavaScript',
          bio: 'Demo student profile for testing'
        },
        createdAt: new Date().toISOString()
      });
    }

    // Create a demo employee
    const employeeEmail = 'employee@demo.com';
    const employeePassword = 'demo123';
    
    const { data: employeeAuth, error: employeeError } = await supabase.auth.admin.createUser({
      email: employeeEmail,
      password: employeePassword,
      user_metadata: { name: 'Demo Employee', userType: 'employee' },
      email_confirm: true
    });

    if (!employeeError && employeeAuth.user) {
      await kv.set(`user:${employeeAuth.user.id}`, {
        id: employeeAuth.user.id,
        name: 'Demo Employee',
        email: employeeEmail,
        userType: 'employee',
        profile: {
          company: 'Google',
          position: 'Senior Software Engineer',
          department: 'Engineering',
          experience: '5 years',
          bio: 'Demo employee profile for testing'
        },
        createdAt: new Date().toISOString()
      });
    }

    return c.json({ 
      message: 'Demo data initialized successfully',
      credentials: {
        student: { email: studentEmail, password: studentPassword },
        employee: { email: employeeEmail, password: employeePassword }
      }
    });
  } catch (error) {
    console.log('Demo init error:', error);
    return c.json({ error: 'Failed to initialize demo data' }, 500);
  }
});

// Health check
app.get('/make-server-9a7a8433/health', (c) => {
  return c.json({ status: 'healthy', timestamp: new Date().toISOString() });
});

Deno.serve(app.fetch);