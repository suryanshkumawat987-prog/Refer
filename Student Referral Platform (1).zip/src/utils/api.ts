import { projectId, publicAnonKey } from './supabase/info';

const API_BASE_URL = `https://${projectId}.supabase.co/functions/v1/make-server-9a7a8433`;

interface ApiResponse<T> {
  data?: T;
  error?: string;
}

class ApiClient {
  private accessToken: string | null = null;

  setAccessToken(token: string | null) {
    this.accessToken = token;
  }

  private async makeRequest<T>(
    endpoint: string, 
    options: RequestInit = {}
  ): Promise<ApiResponse<T>> {
    try {
      const headers = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.accessToken || publicAnonKey}`,
        ...options.headers,
      };

      const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        ...options,
        headers,
      });

      const data = await response.json();

      if (!response.ok) {
        console.error(`API Error [${response.status}]:`, data);
        return { error: data.error || `Request failed with status ${response.status}` };
      }

      return { data };
    } catch (error) {
      console.error('API Client Error:', error);
      return { error: 'Network error occurred' };
    }
  }

  // Authentication
  async register(userData: {
    email: string;
    password: string;
    name: string;
    userType: 'student' | 'employee';
    profile: any;
  }) {
    return this.makeRequest('/register', {
      method: 'POST',
      body: JSON.stringify(userData),
    });
  }

  async login(credentials: { email: string; password: string }) {
    return this.makeRequest('/login', {
      method: 'POST',
      body: JSON.stringify(credentials),
    });
  }

  // Applications
  async submitApplication(application: {
    jobTitle: string;
    company: string;
    jobUrl: string;
    description: string;
  }) {
    return this.makeRequest('/applications', {
      method: 'POST',
      body: JSON.stringify(application),
    });
  }

  async getStudentApplications() {
    return this.makeRequest('/applications/student');
  }

  async getCompanyApplications() {
    return this.makeRequest('/applications/company');
  }

  async referStudent(applicationId: string) {
    return this.makeRequest(`/applications/${applicationId}/refer`, {
      method: 'POST',
    });
  }

  // File uploads
  async uploadResume(file: File) {
    const formData = new FormData();
    formData.append('resume', file);

    return this.makeRequest('/upload-resume', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.accessToken || publicAnonKey}`,
      },
      body: formData,
    });
  }

  // Profile
  async getProfile() {
    return this.makeRequest('/profile');
  }

  async updateProfile(profileData: {
    name: string;
    profile: any;
  }) {
    return this.makeRequest('/profile', {
      method: 'PUT',
      body: JSON.stringify(profileData),
    });
  }

  // Health check
  async healthCheck() {
    return this.makeRequest('/health');
  }
}

export const apiClient = new ApiClient();